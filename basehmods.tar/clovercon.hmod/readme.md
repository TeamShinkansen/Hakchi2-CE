---
Name: Clovercon Hack
Creator: Cluster
---
This module installs a custom clovercon gamepad driver.

## Features

- It allows the use of button combination to open menu
- Autofire
- Start button simulation on second controller (for Famicom Mini)

Module by cluster/Updated by madmonkey & KMFDManic  
Hakchi module system by madmonkey  
NES Mini shell integration by Cluster  
(c) 2016-2017
