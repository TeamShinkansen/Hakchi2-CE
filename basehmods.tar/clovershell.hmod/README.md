---
Name: Clovershell Daemon
Creator: Cluster
---
This hakchi mod allows access to the shell to execute commands and transfer files directly via USB, without UART and FEL.

If this mod is uninstalled, hakchi will fallback to simulating a network adaptor and will run ssh, telnet, and ftp servers.