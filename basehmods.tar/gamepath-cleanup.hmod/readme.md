---
Name: Gamepath Cleanup
Creator: DanTheMan827
---
This mod will delete the old gamepath to free up space for syncing games after upgrading to hakchi2 ce.