---
Name: NTFS-3G
Creator: skogaby
---
NTFS-3G is an open source cross-platform implementation of the Microsoft Windows NTFS file system with read-write support.

It is required if you want to use a NTFS formatted USB drive or SD card.

NTFS-3G is developed by Tuxera and is dual-licensed GNU GPL/Proprietary