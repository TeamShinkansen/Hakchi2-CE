---
Name: Copyleft Text
Creator: Cluster
---
This adds copyleft text to the copyright header in the UI.